import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewimage',
  templateUrl: './viewimage.component.html',
  styleUrls: ['./viewimage.component.css']
})
export class ViewimageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
