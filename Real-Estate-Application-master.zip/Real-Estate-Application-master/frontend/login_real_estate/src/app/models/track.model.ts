export class track {
    trackId:number;
    visitorId:number;
    propertyId:number;
    location:string;
}