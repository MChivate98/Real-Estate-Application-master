export class User{
    id:number;
    fullname:string;
    mobileno:string;
    email:string;
    password:string;
    role:string;
   

    constructor(){
      
    }

}