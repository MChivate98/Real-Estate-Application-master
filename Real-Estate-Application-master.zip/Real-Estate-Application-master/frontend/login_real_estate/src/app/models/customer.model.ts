export class Customer {
    emailId:string;
    name:string;
    password:string;
    phoneNo:string;
    username:string;
    role:string;
}
