export class Property {
    location : string;
    address : string;
    price : number;
    propertyCategory : string;
    propertyType : string;
    customerId:number;
    propertyId:number;
    contact:number;
}
